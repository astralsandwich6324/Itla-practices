# GUI-Modern-Parte-2-Formulario-Moderno-y-Plano-C-Sharp-y-WinForm
<img src="https://rjcodeadvance.com/wp-content/uploads/2019/09/Formulario-moderno-plano-visual-studio-c-sharp-windows-form-dashboard.jpg">
<h1>Tutorial</h1>
<h2>YouTube</h2>
https://www.youtube.com/watch?v=NiQRq_u3vQU
<h2>Blog</h2>
https://rjcodeadvance.com/gui-parte-2-disenar-formulario-moderno,-abrir-form-en-panel-con-c#-y-windows-form-–-version-basica-(beta)
