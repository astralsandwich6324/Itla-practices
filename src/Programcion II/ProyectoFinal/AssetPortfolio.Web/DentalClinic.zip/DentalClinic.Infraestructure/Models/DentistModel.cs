﻿

namespace DentalClinic.Infraestructure.Models
{
    public class DentistModel
    {
         
        
    }
}