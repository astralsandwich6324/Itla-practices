﻿namespace DentalClinic.Infraestructure.Models
{
    public class AppointmentModel 
    {
         
        
    }

    
}